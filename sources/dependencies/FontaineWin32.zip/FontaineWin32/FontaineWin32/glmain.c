#include "gl_font_renderer.h"
#include "tiler.h"

#include <SDL.h>
#define _USE_MATH_DEFINES
#include <math.h>
#include <stdbool.h>

#undef main

int
main(int argc, char *argv[])
{
    struct FontaineFont *font = NULL;
    struct TileContext *tile = NULL;
    struct GLFontRenderer *renderer = NULL;
    bool quit = false;
    int i, j;
    uint32_t colors[] = {
        0x4AA0F0FF,
        0xCAFEF0FF,
        0xFF000090,
    };
    uint32_t freeze_tile;

    int scale = 1;
    SDL_Surface *screen = SDL_SetVideoMode(480 * scale, 272 * scale, 0, SDL_OPENGL);

    font = fontaine_new(NULL, NULL, NULL);
    tile = tile_context_new();
    tile_context_load_file(tile, "out.tile");
    tile_context_dump(tile);
    renderer = gl_font_renderer_new_with_tile(font, screen->w / scale, screen->h / scale, tile);

    gl_font_renderer_enable_blending(renderer);

    freeze_tile = gl_font_renderer_lookup_image(renderer, "Freeze");

    for (i=0; !quit; i++) {
        SDL_Event e;
        while (!quit && SDL_PollEvent(&e)) {
            switch (e.type) {
                case SDL_QUIT:
                    quit = true;
                    break;
                default:
                    /* Unhandled event */
                    break;
            }
        }

        gl_font_renderer_clear(renderer, 0.1f, 0.2f, 0.3f, 0.0f);

        gl_font_renderer_render_image(renderer, 0.f, 0.f, 1.f, 0.f, 0xFFFFFFFF, (SDL_GetTicks()/1000)%15);

        for (j=0; j<10; j++) {
            gl_font_renderer_render_image(renderer,
                    30.f + sinf(j * 3.3f * M_PI + SDL_GetTicks()*(j+1)*0.00003f) * (90.f + 5.0f * j),
                    30.f + cosf(j * 7.2f * M_PI + (j+3)*SDL_GetTicks() * 0.00007f) * (60.f - 5.f * j),
                    1.f + 0.5f * sinf(SDL_GetTicks() * 0.0002f), SDL_GetTicks() * 0.0002f + 5*j, 0xFFFFFFFF, j%7);
        }

        gl_font_renderer_flush(renderer);

        for (j=0; j<50; j++) {
            gl_font_renderer_enqueue(renderer,
                25.f, 25.f + 10.f*j, 2.f + fabsf(3.f * sinf(i*0.0007f)), 0.002f * (i + j),
                colors[j%(sizeof(colors)/sizeof(colors[0]))], "Hallo Welt Das Ist ein Test!");
        }

        gl_font_renderer_flush(renderer);

        SDL_Delay(10);
        SDL_GL_SwapBuffers();
    }

    gl_font_renderer_free(renderer);
    fontaine_free(font);
    tile_context_destroy(tile);

    SDL_Quit();

    return 0;
}
