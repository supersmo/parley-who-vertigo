#include "gl_font_renderer.h"

#include <string.h>
#include <math.h>
#include <stdio.h>

#include <vector>

struct FontVertex {
    float pos[2];
    float tex[2];
    float color[4];
};

template <typename T>
struct GenericBuffer : public std::vector<T> {
    T *allocate(size_t required)
    {
        size_t oldsize = std::vector<T>::size();
        std::vector<T>::resize(oldsize + required);
        return std::vector<T>::data() + oldsize;
    }
};

struct FontBuffer : public GenericBuffer<FontVertex> {};
struct TileBuffer : public GenericBuffer<TileVertex> {};

struct GLFontRenderer *
gl_font_renderer_new(struct FontaineFont *font, int width, int height)
{
	glewInit();
    return gl_font_renderer_new_with_tile(font, width, height, nullptr);
}

static void
check_shader_compiler(GLuint shader)
{
    GLint success = GL_FALSE;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
    if (success != GL_TRUE) {
        GLint size = 0;
        glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &size);
        char *tmp = new char[size];
        glGetShaderInfoLog(shader, size, NULL, tmp);
        printf("==\n%s\n==\n", tmp);
        delete [] tmp;
    }
}

static GLuint
gl_build_program(const char *vertex_shader_src, const char *fragment_shader_src)
{
    GLuint result = glCreateProgram();

    GLuint shader = glCreateShader(GL_VERTEX_SHADER);

    glShaderSource(shader, 1, &vertex_shader_src, NULL);
    glCompileShader(shader);
    check_shader_compiler(shader);
    glAttachShader(result, shader);
    glDeleteShader(shader);

    shader = glCreateShader(GL_FRAGMENT_SHADER);

    glShaderSource(shader, 1, &fragment_shader_src, NULL);
    glCompileShader(shader);
    check_shader_compiler(shader);
    glAttachShader(result, shader);
    glDeleteShader(shader);

    glLinkProgram(result);

    GLint success = GL_FALSE;
    glGetProgramiv(result, GL_LINK_STATUS, &success);
    if (success == GL_FALSE) {
        printf("Linking failed\n");
    }

    return result;
}


static GLuint
gl_build_texture(GLenum format, GLint filtering, int width, int height, const void *buffer)
{
    GLuint result = 0;

    glGenTextures(1, &result);
    glBindTexture(GL_TEXTURE_2D, result);

    GLenum internalformat = format;

    GLint min_filtering = (filtering == GL_NEAREST) ? GL_NEAREST_MIPMAP_NEAREST : GL_NEAREST_MIPMAP_LINEAR;

    glTexImage2D(GL_TEXTURE_2D, 0, internalformat, width, height, 0, format, GL_UNSIGNED_BYTE, buffer);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, min_filtering);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filtering);
    glGenerateMipmap(GL_TEXTURE_2D);

    return result;
}

struct GLFontRenderer *
gl_font_renderer_new_with_tile(struct FontaineFont *font, int width, int height, struct TileContext *tile)
{
    struct GLFontRenderer *renderer = (struct GLFontRenderer *)
        font->malloc_func(sizeof(struct GLFontRenderer), font->alloc_user_data);

    renderer->font = font;
    renderer->tile = tile;
    renderer->width = width;
    renderer->height = height;

    const char *vertex_shader_src =
#if defined(USE_OPENGL_ES)
        "precision mediump float;\n"
#endif
        "attribute vec4 vtxcoord;\n"
        "attribute vec2 texcoord;\n"
        "attribute vec4 vtxcolor;\n"
        "uniform vec2 size;\n"
        "varying vec2 tex;\n"
        "varying vec4 color;\n"
        "void main() {\n"
        "gl_Position = vec4(2.0 * (vtxcoord.xy / size) - vec2(1.0, 1.0), 0.0, 1.0);\n"
        "gl_Position.y *= -1.0; tex = texcoord;\n"
        "color = vtxcolor;\n"
        "}\n"
    ;

    const char *fragment_shader_src =
#if defined(USE_OPENGL_ES)
        "precision mediump float;\n"
#endif
        "varying vec2 tex;\n"
        "varying vec4 color;\n"
        "uniform sampler2D sampler;\n"
        "void main() {\n"
        "gl_FragColor = vec4(color.rgb, texture2D(sampler, tex).a * color.a);\n"
        "}\n"
    ;

    renderer->glfont.program = gl_build_program(vertex_shader_src, fragment_shader_src);

    glUseProgram(renderer->glfont.program);
    glUniform2f(glGetUniformLocation(renderer->glfont.program, "size"), (float)width, (float)height);
    renderer->glfont.vtxcoord_loc = glGetAttribLocation(renderer->glfont.program, "vtxcoord");
    renderer->glfont.texcoord_loc = glGetAttribLocation(renderer->glfont.program, "texcoord");
    renderer->glfont.vtxcolor_loc = glGetAttribLocation(renderer->glfont.program, "vtxcolor");
    glUseProgram(0);

    int w = 8 * 16;
    int h = 8 * 8;

    unsigned char *buffer = (unsigned char *)font->malloc_func(w * h, font->alloc_user_data);

    int ch;
    for (ch=0; ch<128; ch++) {
        int row = ch / 16;
        int column = ch % 16;

        char tmpstr[2];
        int tmpw = 0;
        int tmph = 0;
        unsigned char *bmp = NULL;
        int yy;

        tmpstr[0] = (char)ch;
        tmpstr[1] = '\0';
        bmp = fontaine_render(font, tmpstr, &tmpw, &tmph);

        for (yy=0; yy<tmph; yy++) {
            int xx;
            for (xx=0; xx<tmpw; xx++) {
                buffer[(row * 8 + yy) * w + (column * 8 + xx)] = bmp[yy*tmpw + xx];
            }
        }

        fontaine_free_pixels(font, bmp);
    }

    renderer->glfont.texture = gl_build_texture(GL_ALPHA, GL_NEAREST, w, h, buffer);

    renderer->glfont.buffer = new FontBuffer();

    font->free_func(buffer, font->alloc_user_data);

    if (renderer->tile) {
        vertex_shader_src =
#if defined(USE_OPENGL_ES)
            "precision mediump float;\n"
#endif
            "attribute vec4 vtxcoord;\n"
            "attribute vec2 texcoord;\n"
            "attribute vec4 vtxcolor;\n"
            "uniform vec2 size;\n"
            "varying vec2 tex;\n"
            "varying vec4 color;\n"
            "void main() {\n"
            "gl_Position = vec4(2.0 * (vtxcoord.xy / size) - vec2(1.0, 1.0), 0.0, 1.0);\n"
            "gl_Position.y *= -1.0; tex = texcoord;\n"
            "color = vtxcolor;\n"
            "}\n"
        ;

        fragment_shader_src =
#if defined(USE_OPENGL_ES)
            "precision mediump float;\n"
#endif
            "varying vec2 tex;\n"
            "varying vec4 color;\n"
            "uniform sampler2D sampler;\n"
            "void main() {\n"
            "gl_FragColor = color * texture2D(sampler, tex);\n"
            "}\n"
        ;

        renderer->gltile.program = gl_build_program(vertex_shader_src, fragment_shader_src);

        glUseProgram(renderer->gltile.program);
        glUniform2f(glGetUniformLocation(renderer->gltile.program, "size"), (float)width, (float)height);
        renderer->gltile.vtxcoord_loc = glGetAttribLocation(renderer->gltile.program, "vtxcoord");
        renderer->gltile.vtxcolor_loc = glGetAttribLocation(renderer->gltile.program, "vtxcolor");
        renderer->gltile.texcoord_loc = glGetAttribLocation(renderer->gltile.program, "texcoord");
        glUseProgram(0);

        uint16_t w16, h16;
        const char *buf = tile_context_get_rgba(renderer->tile, &w16, &h16);
        renderer->gltile.texture = gl_build_texture(GL_RGBA, GL_LINEAR, (int)w16, (int)h16, buf);

        renderer->gltile.buffer = new TileBuffer();
    }

    return renderer;
}

void
gl_font_renderer_enable_blending(struct GLFontRenderer *renderer)
{
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

void
gl_font_renderer_clear(struct GLFontRenderer *renderer, float r, float g, float b, float a)
{
    glClearColor(r, g, b, a);
    glClear(GL_COLOR_BUFFER_BIT);
}

struct Vec2 {
    Vec2(float x=0.f, float y=0.f) : x(x), y(y) {}

    Vec2 operator+(const Vec2 &o) const { return Vec2(x + o.x, y + o.y); }
    Vec2 operator-(const Vec2 &o) const { return Vec2(x - o.x, y - o.y); }

    float x;
    float y;
};

struct Rotation {
    Rotation(float angle, const Vec2 &center) : cosv(cosf(angle)), sinv(sinf(angle)), center(center) {}

    Vec2 operator*(const Vec2 &other) const {
        Vec2 o = other - center;
        return Vec2(o.x * cosv - o.y * sinv, o.y * cosv + o.x * sinv) + center;
    }

    float cosv;
    float sinv;
    Vec2 center;
};

void
gl_font_renderer_enqueue(struct GLFontRenderer *renderer, float x, float y,
        float scale, float angle, uint32_t color, const char *text)
{
    int len = strlen(text);

    int w = 8 * len;
    int h = 8;

    w *= scale;
    h *= scale;

    Rotation rotation(angle, Vec2(x + w/2, y + h/2));

    float r = float((color >> 24) & 0xFF) / 255.f;
    float g = float((color >> 16) & 0xFF) / 255.f;
    float b = float((color >> 8) & 0xFF) / 255.f;
    float a = float((color >> 0) & 0xFF) / 255.f;

    float *vtxdata = &(renderer->glfont.buffer->allocate(len * 6)->pos[0]);

    float *wp = vtxdata;
    for (int i=0; i<len; i++) {
        int ch = text[i];
        if (ch < 32 || ch > 127) {
            ch = ' ';
        }

        Vec2 v0 = rotation * Vec2(x, y);
        Vec2 v1 = rotation * Vec2(x + 8.f * scale, y);
        Vec2 v2 = rotation * Vec2(x + 8.f * scale, y + 8.f * scale);
        Vec2 v3 = rotation * Vec2(x, y + 8.f * scale);
        float s0 = int(ch % 16) / 16.f;
        float t0 = int(ch / 16) / 8.f;
        float s1 = s0 + 1.f / 16.f;
        float t1 = t0 + 1.f / 8.f;

        *wp++ = v0.x; *wp++ = v0.y; *wp++ = s0; *wp++ = t0; *wp++ = r; *wp++ = g; *wp++ = b; *wp++ = a;
        *wp++ = v1.x; *wp++ = v1.y; *wp++ = s1; *wp++ = t0; *wp++ = r; *wp++ = g; *wp++ = b; *wp++ = a;
        *wp++ = v3.x; *wp++ = v3.y; *wp++ = s0; *wp++ = t1; *wp++ = r; *wp++ = g; *wp++ = b; *wp++ = a;

        *wp++ = v1.x; *wp++ = v1.y; *wp++ = s1; *wp++ = t0; *wp++ = r; *wp++ = g; *wp++ = b; *wp++ = a;
        *wp++ = v2.x; *wp++ = v2.y; *wp++ = s1; *wp++ = t1; *wp++ = r; *wp++ = g; *wp++ = b; *wp++ = a;
        *wp++ = v3.x; *wp++ = v3.y; *wp++ = s0; *wp++ = t1; *wp++ = r; *wp++ = g; *wp++ = b; *wp++ = a;

        x += 8.f * scale;
    }
}

uint32_t
gl_font_renderer_lookup_image(struct GLFontRenderer *renderer, const char *name)
{
    return tile_context_lookup_image(renderer->tile, name);
}

void
gl_font_renderer_render_image(struct GLFontRenderer *renderer,
        float x, float y, float scale, float angle, uint32_t color, uint32_t image_id)
{
    uint32_t count = 0;
    uint16_t width = 0;
    uint16_t height = 0;
    const TileVertex *vtx = tile_context_get_tiles(renderer->tile, image_id, &count, &width, &height);
    if (!count) {
        return;
    }

    auto vertices = renderer->gltile.buffer->allocate(count);

    Rotation rotation(angle, Vec2(x + width/2.f, y + height/2.f));

    color = (color & 0xFF) << 24 | ((color >> 8) & 0xFF) << 16 | ((color >> 16) & 0xFF) << 8 | ((color >> 24) & 0xFF);

    for (int i=0; i<count; i++) {
        vertices[i] = vtx[i];

        Vec2 pos = rotation * Vec2(x + (vertices[i].x - width / 2.f) * scale + width / 2.f,
                                   y + (vertices[i].y - height / 2.f) * scale + height / 2.f);

        vertices[i].x = pos.x;
        vertices[i].y = pos.y;
        vertices[i].color = color;
    }
}

template <typename T>
GLenum glTypeFromType();

template <>
GLenum glTypeFromType<float>() { return GL_FLOAT; }

template <typename Vertex, typename Field, int size>
struct VertexAttribPointer {
    VertexAttribPointer(GLuint location, Field *ptr)
        : location(location)
    {
        glVertexAttribPointer(location, size, glTypeFromType<Field>(), GL_FALSE, sizeof(Vertex), ptr);
        glEnableVertexAttribArray(location);
    }

    ~VertexAttribPointer()
    {
        glDisableVertexAttribArray(location);
    }

    VertexAttribPointer(const VertexAttribPointer &) = delete;

    GLuint location;
};

void
gl_font_renderer_flush(struct GLFontRenderer *renderer)
{
    if (renderer->glfont.buffer->size()) {
        glUseProgram(renderer->glfont.program);
        glBindTexture(GL_TEXTURE_2D, renderer->glfont.texture);

        auto first = renderer->glfont.buffer->data();

        VertexAttribPointer<FontVertex,float,2> pos(renderer->glfont.vtxcoord_loc, first->pos);
        VertexAttribPointer<FontVertex,float,2> tex(renderer->glfont.texcoord_loc, first->tex);
        VertexAttribPointer<FontVertex,float,4> col(renderer->glfont.vtxcolor_loc, first->color);

        glDrawArrays(GL_TRIANGLES, 0, renderer->glfont.buffer->size());

        renderer->glfont.buffer->clear();
    }

    if (renderer->gltile.buffer->size()) {
        glUseProgram(renderer->gltile.program);
        glBindTexture(GL_TEXTURE_2D, renderer->gltile.texture);

        auto first = renderer->gltile.buffer->data();

        VertexAttribPointer<TileVertex,float,2> pos(renderer->gltile.vtxcoord_loc, &(first->x));
        VertexAttribPointer<TileVertex,float,2> tex(renderer->gltile.texcoord_loc, &(first->u));

        glVertexAttribPointer(renderer->gltile.vtxcolor_loc, 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(TileVertex), &(first->color));
        glEnableVertexAttribArray(renderer->gltile.vtxcolor_loc);

        glDrawArrays(GL_TRIANGLES, 0, renderer->gltile.buffer->size());

        glDisableVertexAttribArray(renderer->gltile.vtxcolor_loc);

        renderer->gltile.buffer->clear();
    }

    glUseProgram(0);
}

void
gl_font_renderer_free(struct GLFontRenderer *renderer)
{
    if (renderer->tile) {
        delete renderer->gltile.buffer;
        glDeleteTextures(1, &renderer->gltile.texture);
        glDeleteProgram(renderer->gltile.program);
    }

    delete renderer->glfont.buffer;

    glDeleteTextures(1, &renderer->glfont.texture);
    glDeleteProgram(renderer->glfont.program);

    renderer->font->free_func(renderer, renderer->font->alloc_user_data);
}
