#ifndef FONTAINE_H
#define FONTAINE_H

#include <stdlib.h>

/**
 * Fontaine -- C89 8x8 pixel font rendering library
 * 2016-05-30 Thomas Perl <m@thp.io>
 **/

#if defined(__cplusplus)
extern "C" {
#endif

struct FontaineFont {
    void *(*malloc_func)(size_t, void *);
    void (*free_func)(void *, void *);
    void *alloc_user_data;
    int width;
    int height;
    int offset;
    int nchars;
};

__declspec(dllexport) struct FontaineFont *
fontaine_new(void *(*malloc_func)(size_t, void *), void (*free_func)(void *, void *), void *alloc_user_data);

__declspec(dllexport) unsigned char *
fontaine_render(struct FontaineFont *font, const char *msg, int *width, int *height);

__declspec(dllexport) void
fontaine_free_pixels(struct FontaineFont *font, unsigned char *pixels);

__declspec(dllexport) void
fontaine_free(struct FontaineFont *font);

#if defined(__cplusplus)
};
#endif

#endif /* FONTAINE_H */
