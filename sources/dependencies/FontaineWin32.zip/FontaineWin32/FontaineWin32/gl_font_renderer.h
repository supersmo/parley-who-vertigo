#ifndef FONTAINE_GL_FONT_RENDERER_H
#define FONTAINE_GL_FONT_RENDERER_H

#include "fontaine.h"
#include "tiler.h"

#include <stdint.h>

#define GL_GLEXT_PROTOTYPES

#if defined(USE_IPHONE_OS)
#  include <OpenGLES/ES2/gl.h>
#  include <OpenGLES/ES2/glext.h>
#  define USE_OPENGL_ES
#elif defined(USE_OPENGL_ES)
#  include <GLES2/gl2.h>
#  include <GLES2/gl2ext.h>
#elif defined(__APPLE__)
#  include <OpenGL/gl.h>
#elif defined(_WIN32)
#define GLEW_STATIC
#include <GL/glew.h>
#else
#  include <GL/gl.h>
#  include <GL/glext.h>
#endif

#if defined(__cplusplus)
extern "C" {
#endif

struct FontBuffer;
typedef struct FontBuffer FontBuffer;

struct TileBuffer;
typedef struct TileBuffer TileBuffer;

struct GLFontRenderer {
    struct FontaineFont *font;
    struct TileContext *tile;
    int width;
    int height;

    struct {
        GLuint program;
        GLuint texture;
        GLuint vtxcoord_loc;
        GLuint vtxcolor_loc;
        GLuint texcoord_loc;
        FontBuffer *buffer;
    } glfont;

    struct {
        GLuint program;
        GLuint texture;
        GLuint vtxcoord_loc;
        GLuint vtxcolor_loc;
        GLuint texcoord_loc;
        TileBuffer *buffer;
    } gltile;
};

__declspec(dllexport) struct GLFontRenderer *
gl_font_renderer_new(struct FontaineFont *font, int width, int height);

__declspec(dllexport) struct GLFontRenderer *
gl_font_renderer_new_with_tile(struct FontaineFont *font, int width, int height, struct TileContext *tile);

__declspec(dllexport) void
gl_font_renderer_enable_blending(struct GLFontRenderer *renderer);

__declspec(dllexport) void
gl_font_renderer_clear(struct GLFontRenderer *renderer,
        float r, float g, float b, float a);

__declspec(dllexport) void
gl_font_renderer_enqueue(struct GLFontRenderer *renderer,
        float x, float y, float scale, float angle, uint32_t color, const char *text);

__declspec(dllexport) uint32_t
gl_font_renderer_lookup_image(struct GLFontRenderer *renderer, const char *name);

__declspec(dllexport) void
gl_font_renderer_render_image(struct GLFontRenderer *renderer,
        float x, float y, float scale, float angle, uint32_t color, uint32_t image_id);

__declspec(dllexport) void
gl_font_renderer_flush(struct GLFontRenderer *renderer);

__declspec(dllexport) void
gl_font_renderer_free(struct GLFontRenderer *renderer);

#if defined(__cplusplus)
};
#endif

#endif /* FONTAINE_GL_FONT_RENDERER_H */
