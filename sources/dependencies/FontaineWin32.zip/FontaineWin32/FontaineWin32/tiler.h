#pragma once

#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

struct TileVertex {
    float x;
    float y;
    float u;
    float v;
    uint32_t color;
};

typedef struct TileVertex TileVertex;

struct TileContext;

typedef struct TileContext TileContext;

__declspec(dllexport) TileContext *tile_context_new();
__declspec(dllexport) void tile_context_configure(TileContext *ctx, uint16_t atlas_size, uint16_t tile_size, uint8_t padding, uint8_t bleeding);
__declspec(dllexport) void tile_context_load_file(TileContext *ctx, const char *filename);
__declspec(dllexport) void tile_context_load(TileContext *ctx, const char *buf, size_t len);

__declspec(dllexport) void tile_context_save(TileContext *ctx, const char *filename);
__declspec(dllexport) void tile_context_save_png(TileContext *ctx, const char *filename);
__declspec(dllexport) void tile_context_dump(TileContext *ctx);
__declspec(dllexport) void tile_context_add(TileContext *ctx, const char *filename);

__declspec(dllexport) const char *tile_context_get_rgba(TileContext *ctx, uint16_t *width, uint16_t *height);
__declspec(dllexport) uint32_t tile_context_lookup_image(TileContext *ctx, const char *name);
__declspec(dllexport) const TileVertex *tile_context_get_tiles(TileContext *ctx, uint32_t image_id, uint32_t *count, uint16_t *width, uint16_t *height);

__declspec(dllexport) void tile_context_destroy(TileContext *ctx);

#ifdef __cplusplus
}
#endif
