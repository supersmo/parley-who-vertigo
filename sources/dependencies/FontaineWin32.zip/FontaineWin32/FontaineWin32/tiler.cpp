#include  "tiler.h"

#include <cstdio>

#include <string>
#include <cstdint>
#include <vector>
#include <algorithm>

#include "gl_font_renderer.h"

/*
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"
*/

// File format:
// 1. TileHeader
// 2. Array of TileImage Structs
// 3. String table
// 4. Atlas Image Data (raw)

static const uint32_t
TILE_MAGIC = ('T' | ('I' << 8) | ('L' << 16) | ('E' << 24));

struct TileHeader {
    uint32_t magic; // 'T' 'I' 'L' 'E'
    uint16_t atlas_size; // e.g. 1024x1024
    uint16_t tile_size; // e.g. 16x16
    uint8_t padding; // e.g. 3px
    uint8_t bleeding; // e.g. 1px
    uint16_t image_count; // number of images that follow
};

struct TileImage {
    uint16_t width;
    uint16_t height;
	/*
    struct {
        uint16_t id;
    } coordinates[0]; // padded to even number of coordinates
	*/
};

struct StringTable {
    // list of '\0'-terminated strings, followed by an additional
    // '\0' terminator and then '\0'-padded to 4-byte increments
};

struct TileArea {
    TileArea(uint16_t x, uint16_t y, uint16_t w, uint16_t h) : x(x), y(y), w(w), h(h) {}

    uint16_t x;
    uint16_t y;
    uint16_t w;
    uint16_t h;
};

struct Tiles : public std::vector<TileArea> {
    Tiles() = default;
    Tiles(TileHeader &header, int w, int h, bool is_atlas);

    static int
    get_count(TileHeader &header, int side, bool is_atlas)
    {
        return (side + (is_atlas ? (-header.padding) : (header.tile_size - 1))) / (header.tile_size + (is_atlas ? header.padding : 0));
    }

    int columns;
    int rows;
};

Tiles::Tiles(TileHeader &header, int w, int h, bool is_atlas)
    : std::vector<TileArea>()
    , columns(get_count(header, w, is_atlas))
    , rows(get_count(header, h, is_atlas))
{
    int padding = is_atlas ? header.padding : 0;

    for (int row=0; row<rows; row++) {
        int ty = padding + row * (header.tile_size + padding);
        int th = header.tile_size;
        if (th > h - ty) {
            th = h - ty;
        }

        for (int column=0; column<columns; column++) {
            int tx = padding + column * (header.tile_size + padding);
            int tw = header.tile_size;
            if (tw > w - tx) {
                tw = w - tx;
            }

            emplace_back(tx, ty, tw, th);
        }
    }
}

struct RGBAImage {
    RGBAImage(char *buf, int w, int h) : buf(buf), w(w), h(h) {}

    bool contains(RGBAImage &other, TileArea &there, TileArea &here);
    void blit_from(RGBAImage &other, TileArea &there, TileArea &here, bool bleed, TileHeader &header);

    uint32_t *scanline(int x, int y)
    {
        return (uint32_t *)(buf + 4 * (x + (w * y)));
    }

    char *buf;
    int w;
    int h;
};

bool
RGBAImage::contains(RGBAImage &other, TileArea &there, TileArea &here)
{
    int w = std::min(here.w, there.w);
    int h = std::min(here.h, there.h);

    for (int y=0; y<h; y++) {
        const uint32_t *sl_here = scanline(here.x, here.y + y);
        const uint32_t *sl_there = other.scanline(there.x, there.y + y);
        if (memcmp(sl_here, sl_there, w * 4) != 0) {
            return false;
        }
    }

    return true;
}

void
RGBAImage::blit_from(RGBAImage &other, TileArea &there, TileArea &here, bool bleed, TileHeader &header)
{
    int w = std::min(here.w, there.w);
    int h = std::min(here.h, there.h);

    for (int y=0; y<h; y++) {
        uint32_t *sl_here = scanline(here.x, here.y + y);
        uint32_t *sl_there = other.scanline(there.x, there.y + y);
        memcpy(sl_here, sl_there, w * 4);
    }

    if (bleed) {
        for (int i=1; i<=header.bleeding; i++) {
            int y1 = here.y - i;
            int y2 = here.y + h - 1 + i;
            int x1 = here.x - i;
            int x2 = here.x + w - 1 + i;
            // bleed on top
            memcpy(scanline(here.x, y1), scanline(here.x, here.y), w * 4);
            // bleed on bottom
            memcpy(scanline(here.x, y2), scanline(here.x, here.y + h - 1), w * 4);
            for (int y=0; y<h; y++) {
                // bleed to the left
                *scanline(x1, here.y + y) = *scanline(here.x, here.y + y);
                // bleed to the right
                *scanline(x2, here.y + y) = *scanline(here.x + w - 1, here.y + y);
            }
        }
        // corner bleeding (FIXME: make it work for bleeding > 1)
        *scanline(here.x-1, here.y-1) = *scanline(here.x, here.y);
        *scanline(here.x+w, here.y-1) = *scanline(here.x+w-1, here.y);
        *scanline(here.x-1, here.y+h) = *scanline(here.x, here.y+h-1);
        *scanline(here.x+w, here.y+h) = *scanline(here.x+w-1, here.y+h-1);
    }
}

struct InMemoryImage {
    InMemoryImage(const std::string &filename, TileHeader &header, uint16_t width, uint16_t height)
        : filename(filename)
        , image()
        , ids()
        , tiles(header, width, height, false)
        , vtx()
    {
        image.width = width;
        image.height = height;
    }

    InMemoryImage(const InMemoryImage &) = delete;
    InMemoryImage(InMemoryImage &&old) = default;
    InMemoryImage &operator=(const InMemoryImage &) = delete;

    std::string filename;
    TileImage image;
    std::vector<uint16_t> ids;

    Tiles tiles;
    std::vector<TileVertex> vtx;
};

struct TileContext {
    TileContext();
    ~TileContext();

    void configure(uint16_t atlas_size, uint16_t tile_size, uint8_t padding, uint8_t bleeding);
    bool load(const char *buf, size_t len);
    void save(const char *filename);
    void save_png(const char *filename);
    void dump();
    void add(const char *filename);
    const char *get_rgba(uint16_t *width, uint16_t *height);
    uint32_t lookup_image(const char *basename);
    const TileVertex *get_tiles(uint32_t image_id, uint32_t *count, uint16_t *width, uint16_t *height);

    uint16_t insert_tile(RGBAImage &image, TileArea &area);
    void generate_vertices(InMemoryImage &image);

    TileHeader header;
    std::vector<InMemoryImage> images;
    std::vector<char> pixels;
    Tiles tiles;
};

TileContext::TileContext()
{
    header.magic = TILE_MAGIC;
    configure(1024, 32, 2, 1);
    header.image_count = 0;
}

TileContext::~TileContext()
{
    // TODO
}

void
TileContext::configure(uint16_t atlas_size, uint16_t tile_size, uint8_t padding, uint8_t bleeding)
{
    header.atlas_size = atlas_size;
    header.tile_size = tile_size;
    header.padding = padding;
    header.bleeding = bleeding;
    header.image_count = 0;

    images.clear();

    pixels.clear();
    pixels.resize(atlas_size * atlas_size * 4);

    tiles = Tiles(header, atlas_size, atlas_size, true);
}

bool
TileContext::load(const char *buf, size_t len)
{
    if (len < sizeof(header)) {
        return false;
    }

    off_t offset = 0;

    TileHeader tmp;
    memcpy(&tmp, buf, sizeof(tmp));
    if (tmp.magic != TILE_MAGIC) {
        return false;
    }

    offset += sizeof(tmp);

    configure(tmp.atlas_size, tmp.tile_size, tmp.padding, tmp.bleeding);

    for (int i=0; i<tmp.image_count; i++) {
        if (len < offset + sizeof(TileImage)) {
            return false;
        }

        TileImage tmp2;
        memcpy(&tmp2, buf + offset, sizeof(tmp2));
        offset += sizeof(tmp2);

        images.emplace_back("", header, tmp2.width, tmp2.height);
        auto &im = images.back();
        for (uint32_t i=0; i<im.tiles.size(); i++) {
            if (len < offset + sizeof(uint16_t)) {
                return false;
            }
            im.ids.emplace_back(*((uint16_t *)(buf + offset)));
            offset += sizeof(uint16_t);
        }

        if (im.tiles.size() % 2 != 0) {
            offset += sizeof(uint16_t);
        }

        generate_vertices(im);
    }

    for (int i=0; i<tmp.image_count; i++) {
        const char *begin = buf + offset;
        const char *pos = begin;
        while ((off_t)len > offset && *pos != '\0') {
            pos++;
            offset++;
        }

        if (offset >= (off_t)len) {
            return false;
        }

        images[i].filename = begin;
        offset++;
    }

    if (buf[offset] != '\0') {
        return false;
    }

    offset++;

    while (offset % 4 != 0) {
        if (buf[offset] != '\0') {
            return false;
        }

        offset++;
    }

    printf("Image data: %zu bytes\n", (size_t)(len - offset));

    if ((len - offset) != pixels.size()) {
        return false;
    }

    memcpy(pixels.data(), buf + offset, pixels.size());

    return true;
}

void
TileContext::save(const char *filename)
{
    FILE *fp = fopen(filename, "wb");

    header.image_count = (uint16_t)images.size();

    fwrite(&header, sizeof(header), 1, fp);
    for (auto &i: images) {
        fwrite(&i.image, sizeof(i.image), 1, fp);
        fwrite(i.ids.data(), sizeof(i.ids[0]), i.ids.size(), fp);
        if (i.ids.size() % 2 != 0) {
            uint16_t x = 0;
            fwrite(&x, sizeof(x), 1, fp);
        }
    }

    uint32_t string_table_size = 0;
    for (auto &i: images) {
        size_t len = i.filename.length() + 1;
        fwrite(i.filename.c_str(), len, 1, fp);
        string_table_size += len;
    }
    char tmp = '\0';
    fwrite(&tmp, 1, 1, fp);
    string_table_size++;

    while (string_table_size % 4 != 0) {
        fwrite(&tmp, 1, 1, fp);
        string_table_size++;
    }

    // TODO: Remove any trailing zeroes from the pixels data and/or do run-length encoding
    fwrite(pixels.data(), pixels.size(), 1, fp);

    fclose(fp);
}

void
TileContext::save_png(const char *filename)
{
#if 0
    stbi_write_png(filename, header.atlas_size, header.atlas_size, 4, pixels.data(), 4 * header.atlas_size);
#endif
}

void
TileContext::dump()
{
#if 0
    RGBAImage atlas(pixels.data(), header.atlas_size, header.atlas_size);

    printf("== Tile Context ==\n");
    printf("Atlas size: %d\n", (int)header.atlas_size);
    printf("Tile size: %d\n", (int)header.tile_size);
    printf("Padding: %d\n", (int)header.padding);
    printf("Bleeding: %d\n", (int)header.bleeding);
    printf("==\n");
    printf("Images (%zu entries):\n", images.size());
    int i = 0;
    for (auto &img: images) {
        printf(" - '%s' (%dx%d), %zu tiles\n", img.filename.c_str(), (int)img.image.width, (int)img.image.height, img.ids.size());

        bool dump_png = false;
        if (dump_png) {
            size_t imgsz = 4 * img.image.width * img.image.height;
            char *tmp = (char *)malloc(imgsz);
            memset(tmp, 0, imgsz);
            RGBAImage rgba(tmp, img.image.width, img.image.height);

            int j = 0;
            for (auto &tile: img.tiles) {
                auto area = tiles[img.ids[j]];
                rgba.blit_from(atlas, area, tile, false, header);
                j++;
            }

            char *fn;
            asprintf(&fn, "dump-%d-%s.png", i++, img.filename.c_str());
            stbi_write_png(fn, rgba.w, rgba.h, 4, rgba.buf, 4 * rgba.w);
            free(fn);
            free(tmp);
        }

        /*
        printf("Tile IDs:");
        for (auto id: i.ids) {
            printf(" %d,", id);
        }
        printf("\n");
        */
    }
    printf("==\n");
#endif
}

void
TileContext::add(const char *filename)
{
#if 0
    int w = 0, h = 0, channels = 0;
    stbi_uc *buf = stbi_load(filename, &w, &h, &channels, 4);

    std::string fn = filename;
    auto pos = fn.rfind('/');
    if (pos != std::string::npos) {
        fn = fn.substr(pos + 1);
    }
    pos = fn.rfind('.');
    if (pos != std::string::npos) {
        fn = fn.substr(0, pos);
    }

    images.emplace_back(fn.c_str(), header, w, h);
    auto &im = images.back();

    RGBAImage rgba((char *)buf, w, h);

    printf("%s -> '%s' (%dx%d), %zu tiles\n", filename, fn.c_str(), w, h, im.tiles.size());
    for (auto &tile: im.tiles) {
        im.ids.push_back(insert_tile(rgba, tile));
    }

    generate_vertices(im);
    stbi_image_free(buf);
#endif
}

const char *
TileContext::get_rgba(uint16_t *width, uint16_t *height)
{
    *width = header.atlas_size;
    *height = header.atlas_size;
    return pixels.data();
}

uint32_t
TileContext::lookup_image(const char *basename)
{
    uint32_t result = 0;

    for (int i=0; i<images.size(); i++) {
        auto &im = images[i];
        if (im.filename == basename) {
            return i;
        }
    }

    return 0xFFFF;
}

const TileVertex *
TileContext::get_tiles(uint32_t image_id, uint32_t *count, uint16_t *width, uint16_t *height)
{
    if (image_id >= images.size()) {
        *count = 0;
        return nullptr;
    }

    auto &im = images[image_id];

    *count = im.vtx.size();
    *width = im.image.width;
    *height = im.image.height;

    return im.vtx.data();
}

uint16_t
TileContext::insert_tile(RGBAImage &image, TileArea &area)
{
    //printf("insert_tile(w=%d, h=%d, tx=%d, ty=%d, tw=%d, th=%d)\n", image.w, image.h, area.x, area.y, area.w, area.h);

    RGBAImage atlas(pixels.data(), header.atlas_size, header.atlas_size);

    for (int i=0; i<tiles.size(); i++) {
        auto &tile = tiles[i];

        if (atlas.contains(image, area, tile)) {
            return i;
        }
    }

    for (int i=0; i<tiles.size(); i++) {
        auto &tile = tiles[i];

        bool empty = true;
        for (auto &image: images) {
            if (std::find(image.ids.begin(), image.ids.end(), i) != image.ids.end()) {
                empty = false;
                break;
            }
        }

        if (empty) {
            atlas.blit_from(image, area, tile, true, header);
            return i;
        }
    }

    printf("NO SLOT\n");
    // TODO: Find empty spot to insert
    return 0;
}

void
TileContext::generate_vertices(InMemoryImage &image)
{
    image.vtx.clear();
    image.vtx.resize(6 * image.tiles.rows * image.tiles.columns);

    TileVertex *dest = &(image.vtx[0]);

    float scale = 1.f / header.atlas_size;

    int i = 0;
    int j = 0;
    for (int row=0; row<image.tiles.rows; row++) {
        for (int column=0; column<image.tiles.columns; column++) {
            auto &tile = image.tiles[i];
            auto &area = tiles[image.ids[i]];

            float x0 = tile.x,          y0 = tile.y,
                  x1 = tile.x + tile.w, y1 = tile.y + tile.h;

            float u0 = area.x * scale,            v0 = area.y * scale,
                  u1 = (area.x + tile.w) * scale, v1 = (area.y + tile.h) * scale;

            TileVertex
                a{x0, y0, u0, v0, 0xFFFFFFFF},
                b{x0, y1, u0, v1, 0xFFFFFFFF},
                c{x1, y0, u1, v0, 0xFFFFFFFF},
                d{x1, y1, u1, v1, 0xFFFFFFFF};

            *dest++ = a;
            *dest++ = b;
            *dest++ = c;

            *dest++ = b;
            *dest++ = c;
            *dest++ = d;

            i++;
        }
    }
}

TileContext *
tile_context_new()
{
	glewInit();
    return new TileContext();
}

void
tile_context_configure(TileContext *ctx, uint16_t atlas_size, uint16_t tile_size, uint8_t padding, uint8_t bleeding)
{
    ctx->configure(atlas_size, tile_size, padding, bleeding);
}

void
tile_context_load(TileContext *ctx, const char *buf, size_t len)
{
    if (!ctx->load(buf, len)) {
        printf("Error loading tile\n");
    }
}

static char *
file_get_contents(const char *filename, size_t *len)
{
    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        return nullptr;
    }

    fseek(fp, 0, SEEK_END);
    *len = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    char *data = (char *)malloc(*len + 1);
    // In order for this to be used as astring
    data[*len] = '\0';
    fread(data, *len, 1, fp);
    fclose(fp);

    return data;
}

void
tile_context_load_file(TileContext *ctx, const char *filename)
{
    size_t len = 0;
    char *buf = file_get_contents(filename, &len);
    tile_context_load(ctx, buf, len);
    free(buf);
}

void
tile_context_save(TileContext *ctx, const char *filename)
{
    ctx->save(filename);
}

void
tile_context_save_png(TileContext *ctx, const char *filename)
{
    ctx->save_png(filename);
}

void
tile_context_dump(TileContext *ctx)
{
    ctx->dump();
}

void
tile_context_add(TileContext *ctx, const char *filename)
{
    ctx->add(filename);
}

const char *
tile_context_get_rgba(TileContext *ctx, uint16_t *width, uint16_t *height)
{
    return ctx->get_rgba(width, height);
}

uint32_t
tile_context_lookup_image(TileContext *ctx, const char *name)
{
    return ctx->lookup_image(name);
}

const TileVertex *tile_context_get_tiles(TileContext *ctx, uint32_t image_id, uint32_t *count, uint16_t *width, uint16_t *height)
{
    return ctx->get_tiles(image_id, count, width, height);
}

void
tile_context_destroy(TileContext *ctx)
{
    delete ctx;
}
